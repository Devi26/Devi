package com.cg.bean;
import org.springframework.stereotype.Component;

@Component
public class Address {
	
	
	private String state;
	
	
	private String city;
	
	
	private long zipcode;
	
	public Address() {}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public long getZipcode() {
		return zipcode;
	}

	public void setZipcode(long zipcode) {
		this.zipcode = zipcode;
	}
	@Override
	public String toString() {
		return "Address [state=" + state + ", city=" + city + ", zipcode=" + zipcode + "]";
	}	
}
