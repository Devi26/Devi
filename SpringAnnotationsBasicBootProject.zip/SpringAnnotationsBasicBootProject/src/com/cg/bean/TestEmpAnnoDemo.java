package com.cg.bean;

import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan(basePackages="com.cg.bean")
public class TestEmpAnnoDemo {

	public static void main(String[] args) {
		
		ApplicationContext ctx = SpringApplication.run(TestEmpAnnoDemo.class, args);
		
		Employee employee1 = (Employee) ctx.getBean("DeviEmp1");
		System.out.println(employee1);
		
		System.out.println("*************************************");
		
		Emp emp2 = (Emp) ctx.getBean("e2");
		System.out.println(emp2);
		
		User user = (User) ctx.getBean("u1");
		System.out.println(user);
	}
}
