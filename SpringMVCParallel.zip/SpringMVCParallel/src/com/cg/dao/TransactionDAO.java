package com.cg.dao;

import java.util.List;

import com.cg.dto.Transaction;

public interface TransactionDAO {
	Transaction save(Transaction transaction);
	boolean update(Transaction transaction);
	Transaction findOne(long transactionId);
	List<Transaction> findAll();
}