package com.cg.controller;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.dto.Account;

import com.cg.service.BankingServices;

@Controller
public class BankController {
	@Autowired
	BankingServices bankingServices=null;
	public BankingServices getBankingServices() {
		return bankingServices;
	}

	public void setBankingServices(BankingServices bankingServices) {
		this.bankingServices = bankingServices;
	}

	//**************Show Register Page***********
	@RequestMapping(value="/ShowRegisterPage")
	public String dispRegPage(Model model)
	{
		Account rd=new Account();
		model.addAttribute("reg",rd);
		return "OpenAccount";
	}

	//***************Inserting details**********
	@RequestMapping(value="/InsertUser",method=RequestMethod.POST)
	public String addUserDetails(@ModelAttribute(value="reg")
	@Valid Account ac,
	BindingResult result,Model model) {
		System.out.println("no error..."+ac);
		Account rdd=bankingServices.insertUserDetails(ac);
		ArrayList<Account>userList=(ArrayList<Account>) bankingServices.getAllAccountDetails();
		model.addAttribute("account",userList);
		return"ListAllUser";
	}
	//***************Deposit**********
	@RequestMapping(value="/deposit")
	public String ShowDeposit(Model model) {
		Account rd=new Account();
		model.addAttribute("log",rd);
		return "ShowDeposit";
	}
	//***************Deposit action**********
	@RequestMapping(value="/Showdeposit",method=RequestMethod.POST)
	public String deposit(@ModelAttribute(value="log")
	@Valid Account ac,
	BindingResult result,Model model) {	

		float acc=bankingServices.depositAmount(ac.getAccountNo(),ac.getAmt());
		model.addAttribute("dep",acc);
		return"DepositResult";
	}	




	//***************WITHDRAW**********
	@RequestMapping(value="/withdraw")
	public String ShowWithdraw(Model model) {
		Account rd=new Account();
		model.addAttribute("wid",rd);
		return "ShowWithdraw";
	}
	//***************WITHDRAW action**********
	@RequestMapping(value="/ShowWithdraw",method=RequestMethod.POST)
	public String withdraw(@ModelAttribute(value="wid")
	@Valid Account ac,
	BindingResult result,Model model) {	

		float acc=bankingServices.withdrawAmount(ac.getAccountNo(), ac.getAmt(), ac.getPinNumber());
		model.addAttribute("wid",acc);
		return"WithdrawResult";
	}	


	//***************Fund transfer show**********
	@RequestMapping(value="/fundTransfer")
	public String ShowFundTransfer(Model model) {
		Account rd=new Account();
		model.addAttribute("fnd",rd);
		return "ShowFund";
	}
	//***************Fund transfer action**********
	@RequestMapping(value="/ShowFundTransfer",method=RequestMethod.POST)
	public String fundTransfer(@ModelAttribute(value="fnd")
	@Valid Account ac,
	BindingResult result,Model model) {	

		boolean fund=bankingServices.fundTransfer(ac.getAccountNo(), ac.getAccountNo(), ac.getAmt(), ac.getPinNumber());
		model.addAttribute("fundTrans",fund);
		return"FundTransferResult";
	}	
}






