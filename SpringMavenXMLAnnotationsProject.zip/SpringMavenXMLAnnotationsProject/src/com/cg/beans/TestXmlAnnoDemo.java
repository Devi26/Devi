package com.cg.beans;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestXmlAnnoDemo {

	public static void main(String[] args) {
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("CgXMLAnno.xml");
		IGreet g1 = (IGreet) ctx.getBean("object1");
		System.out.println(g1);
		System.out.println("******************************************************************");
		IGreet g2 = (IGreet) ctx.getBean("Object2");
		System.out.println(g2.greetMe());
	}

}
