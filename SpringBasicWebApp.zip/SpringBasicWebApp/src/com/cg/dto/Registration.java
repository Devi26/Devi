package com.cg.dto;

import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Pattern;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

import com.cg.util.MyStringDateUtil;

@Entity
@Table(name="cg_userdetails")
public class Registration {
	
	@Id
	@Column(name="user_name", length=25)
	private String userName;
	
	@Transient
	private String password;
	
	@Transient
	private String confirmPassword;
	
	@Column(name="first_name",length=20)
	private String firstName;
	
	@Column(name="last_name",length=20)
	private String lastName;
	
	@Column(name="user_email",length=20)
	private String email;
	
	@Transient
	private String[] skillSet;
	
	@Column(name="user_skill",length=75)
	private String skillSetStr;
	
	@Column(name="user_gender",length=1)
	private char gender;
	
	@Column(name="user_city",length=15)
	private String city;

	public Registration() {}

	//@NotEmpty(message="User Name Is Mandatory")
	//@Size(min=5, message="Min 5 characters required in username")
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	@NotEmpty(message="Password Is Mandatory")
	@Pattern(regexp="(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}")
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	//@Pattern(regexp= "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})")
	@NotEmpty(message="Re-enter the password ")
	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	@NotEmpty(message="FirstName Is Mandatory")
	@Pattern(regexp="[A-Z][a-z]*" , message="Name should start with capital and" + 
			" only charcaters allowed") //here * indicates zero or more occcureces, if use + in the place of * it indicates one or more occurences.
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	@NotEmpty(message="LastName Is Mandatory")
	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	@Email(message="Invalid email address")
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	
	public String[] getSkillSet() {
		return skillSet;
	}

	public void setSkillSet(String[] skillSet) {
		
		this.skillSet = skillSet;
		
		String skills = MyStringDateUtil.fromArrayToCommaSeparatedString(skillSet);
		setSkillSetStr(skills);
		
		//setSkillSetStr(skillSet.toString());
	}
	
	public String getSkillSetStr() {
		return skillSetStr;
	}

	public void setSkillSetStr(String skillSetStr) {
		this.skillSetStr = skillSetStr;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}


	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "Registration [userName=" + userName + ", password=" + password + ", confirmPassword=" + confirmPassword
				+ ", firstName=" + firstName + ", lastName=" + lastName + ", email=" + email + ", skillSet="
				+ Arrays.toString(skillSet) + ", gender=" + gender + ", city=" + city + "]";
	}
}
