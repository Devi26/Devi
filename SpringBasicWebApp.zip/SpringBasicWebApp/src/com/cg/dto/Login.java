 package com.cg.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "cg_users")
public class Login {
	
	@Id
	@Column(name="user_name", length=20)
	private String username;
	
	@Column //here password name is same in both DB and here
	private String password;
	
	public Login() {}

	public Login(String username, String password) {
		super();
		this.username = username;
		this.password = password;
	}

	@NotEmpty(message="User Name Is Mandatory")
	@Size(min=5, message="Min 5 characters required in username")
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	@NotEmpty(message="Password Is Mandatory")
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "Login [username=" + username + ", password=" + password + "]";
	}
	
}
