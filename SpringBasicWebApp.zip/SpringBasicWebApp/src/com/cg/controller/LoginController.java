package com.cg.controller;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.dto.Login;
import com.cg.dto.Registration;
import com.cg.service.ILoginService;

@Controller
public class LoginController {


	ArrayList<String> cityList = null;
	ArrayList<String> skillSet = null;

	@Autowired
	ILoginService loginService = null;

	public ILoginService getLoginService() {
		return loginService;
	}

	public void setLoginService(ILoginService loginService) {
		this.loginService = loginService;
	}

	@RequestMapping(value="/ShowLoginPage",method=RequestMethod.GET)
	public String displayLoginPage(Model model) {

		//for login purpose
		Login lg = new Login();
		lg.setUsername("Enter UR User name Here");

		model.addAttribute("log", lg);//log is model attribute of Login.jsp Page

		model.addAttribute("compNameObj", "Capgemini"); // modelObjName, ModelObjectValue

		return "Login"; // here Login is ViewName
	}

	/**************Validate User***************/

	@RequestMapping(value="/ValidateUser", method=RequestMethod.POST)

	public String validateUserDetails(
			@ModelAttribute(value="log")
			@Valid Login lg, BindingResult result, Model model) {

		if(result.hasErrors())//only use if statement
		{
			return "Login"; // here login is Login.jsp page
		}
		else {

			if(loginService.isUserExist(lg.getUsername()))
			{
				Login user = loginService.validateUser(lg);		

				if(user!=null) {
					//if(lg.getUsername().equalsIgnoreCase("CG")&& lg.getPassword().equalsIgnoreCase("CG")) {

					model.addAttribute("unmObj", lg.getUsername());
					return "Success";
				}
				else {
					return "Failure";
				}
			}
			else {
				return "redirect:/ShowRegistrationPage.obj";
			}
		}
	}

	/******************Show Registration*******************/

	@RequestMapping(value="/ShowRegistrationPage")
	public String dispRegstPage(Model model) {

		cityList = new ArrayList<>();
		cityList.add("Hyderabad");
		cityList.add("Chennai");
		cityList.add("Pune");
		cityList.add("Mumbai");

		skillSet = new ArrayList<>();
		skillSet.add("Java");
		skillSet.add("Dotnet");
		skillSet.add("Html");
		skillSet.add("Oracle");
		skillSet.add("BI");

		Registration rd = new Registration();
		model.addAttribute("reg", rd);
		model.addAttribute("cList", cityList);
		model.addAttribute("skillList", skillSet);

		return "Registration";
	}


	/**************Insert.obj***************/

	@RequestMapping(value="/InsertUser", method=RequestMethod.POST)
	public String addUserDetails(@ModelAttribute(value="reg")
	@Valid Registration rd, BindingResult result,Model model) {

		if(result.hasErrors()) {
			model.addAttribute("cList", cityList);
			model.addAttribute("skillList", skillSet);
			return "Registration";
		}
		else {
			System.out.println("no error........."+rd);
			Registration rdd = loginService.insertUserDeatails(rd);

			ArrayList<Registration> userList = loginService.getAllUserDetails();
			model.addAttribute("userListObj", userList);

			//model.addAttribute("RegObj", rdd);
			return "ListAllUser";	
		}
	}
	/*****************DeleteUser.obj**************/

	@RequestMapping(value="/deleteUser", method=RequestMethod.GET)
	public String deleteUser(@RequestParam(value="uid") String unm ,Model model) {

		Registration rd = loginService.deleteUser(unm);
		if(rd!=null) {
			ArrayList<Registration> userList = loginService.getAllUserDetails();
			model.addAttribute("userListObj", userList);
			model.addAttribute("MsgObj", "Data deleted");
			return "ListAllUser";
		}
		else {
			return "Error";
		}
	}








	/*****************Validate Registration Details*********************/

	/*@RequestMapping(value="/InsertUser" , method=RequestMethod.POST)
	public String validateRegisterDetails(
			@ModelAttribute(value="reg")
			@Valid Registration registration, BindingResult bindingResult, Model model) {
		if(bindingResult.hasErrors()) {

			return "Registration";
		}

		Registration register = loginService.

		return null;

	}*/
}
