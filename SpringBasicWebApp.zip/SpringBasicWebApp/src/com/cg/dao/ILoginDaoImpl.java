package com.cg.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.dto.Login;
import com.cg.dto.Registration;

@Repository("loginDao")
@Transactional
public class ILoginDaoImpl implements ILoginDao{

	@PersistenceContext
	EntityManager entityManager = null; // we can't use here @AutoWire, since it is a JPA configuration
	
	public EntityManager getEntityManager() {
		return entityManager;
	}


	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public boolean isUserExist(String usn) {
		
		Login usr = entityManager.find(Login.class, usn);
		
		if(usr!=null) {
			
		return true;
	   }
		else {
			return false;
		}
	}

	@Override
	public Login validateUser(Login login) {
		
		Login usr = entityManager.find(Login.class, login.getUsername());
		
		return usr;
	}

	@Override
	public Registration insertUserDeatails(Registration userDetails) {
	
		Login loginObj = new Login();
		
		loginObj.setUsername(userDetails.getUserName());
		loginObj.setPassword(userDetails.getPassword());
		
		StringBuffer str = new StringBuffer();
		for (String tempStr : userDetails.getSkillSet()) {
			
			str.append(tempStr+",");
			//str+=tempStr+",";
		}
		userDetails.setSkillSetStr(str.toString());
		
		entityManager.persist(userDetails);
		entityManager.persist(loginObj);
		entityManager.flush();
		Registration rd = entityManager.find(Registration.class, userDetails.getUserName());
		return rd;
	}


	@Override
	public ArrayList<Registration> getAllUserDetails() {

		String qry = "SELECT reg FROM Registration reg";
		TypedQuery tq = entityManager.createQuery(qry, Registration.class);
		ArrayList<Registration> uList = (ArrayList<Registration>) tq.getResultList();
		
		return uList;
	}


	@Override
	public Registration deleteUser(String usn) {
		
		Registration regDto = entityManager.find(Registration.class, usn);
		
		Login logDto = entityManager.find(Login.class, usn);
		
		entityManager.remove(regDto);
		entityManager.remove(logDto);
		entityManager.flush();
		
		return regDto;
	}

}
