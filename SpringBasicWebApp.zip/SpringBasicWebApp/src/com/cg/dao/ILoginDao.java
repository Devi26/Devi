package com.cg.dao;

import java.util.ArrayList;

import com.cg.dto.Login;
import com.cg.dto.Registration;

public interface ILoginDao {

	public boolean isUserExist(String usn);
	public Login validateUser(Login login);
	public Registration insertUserDeatails(Registration userDetails);
	//for JPQL purpose
	public ArrayList<Registration>  getAllUserDetails();
	//for delete purpose
	public Registration deleteUser(String usn);
}
