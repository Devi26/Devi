package com.cg.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ILoginDao;
import com.cg.dto.Login;
import com.cg.dto.Registration;

@Service("loginService")
public class ILoginServiceImpl implements ILoginService {

	@Autowired
	ILoginDao logDao = null;

	//generate getter setter for loginDao
	public ILoginDao getLoginDao() {
		return logDao;
	}

	public void setLoginDao(ILoginDao loginDao) {
		this.logDao = loginDao;
	}

	@Override
	public boolean isUserExist(String usn) {

		return logDao.isUserExist(usn);
	}

	@Override
	public Login validateUser(Login login) {

		Login dbUser = logDao.validateUser(login);
		
		if((login.getUsername().equalsIgnoreCase(dbUser.getUsername()))&&
				login.getPassword().equalsIgnoreCase(dbUser.getPassword())) {
			
			return login;
		}
		else {
			
			return null;
		}
	}

	@Override
	public Registration insertUserDeatails(Registration userDetails) {
		
		return logDao.insertUserDeatails(userDetails);
	}

	@Override
	public ArrayList<Registration> getAllUserDetails() {
		
		return logDao.getAllUserDetails();
	}

	@Override
	public Registration deleteUser(String usn) {
		return logDao.deleteUser(usn);
	}

}
