package com.cg.bean;

import org.springframework.beans.factory.annotation.Value;

public class NewYearWish implements IGreet {
	
	@Value("Devi Ratnala")
	String firstName;
	@Value("2020")
	int year;
	
	public NewYearWish() {
		System.out.println("In NewYearWish " + "Constructor");
	}	
	
	public NewYearWish(String firstName, int year) {
		super();
		this.firstName = firstName;
		this.year = year;
		System.out.println("In NewYearWish" + "Parameterized Constructor");
	}

	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
		System.out.println("setFirstName called");
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
		System.out.println("setYear called");
	}
	@Override
	public String greetMe() {
		
		return "Happy New Year : " + year + " : " + firstName;
	}

	@Override
	public String toString() {
		return "NewYearWish [firstName=" + firstName + ", year=" + year + "]";
	}
	
}

