package com.cg.bean;

import java.util.ArrayList;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringConfig {
	@Bean
	public ArrayList<Address> getAddList(){
	
		Address ad1 = new Address();
		ad1.setCity("Bhimvaram");
		ad1.setState("Andhra Pradesh");
		ad1.setZipcode(534208);
		
		Address ad2 = new Address();
		ad2.setCity("Pune");
		ad2.setState("Maharastra");
		ad2.setZipcode(500056);
		
		ArrayList<Address> adList = new ArrayList<Address>();
		adList.add(ad1);
		adList.add(ad2);
		return adList;
		
	}

}
