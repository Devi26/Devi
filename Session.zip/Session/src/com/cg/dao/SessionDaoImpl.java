package com.cg.dao;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
import com.cg.dto.ScheduledSession; 

@Repository
@Transactional
public class SessionDaoImpl implements SessionDao {
	@PersistenceContext
	EntityManager entityManager = null;
	//getter,setters
	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public List<ScheduledSession> getAllSessions() {
		return entityManager.createQuery("from ScheduledSession s", ScheduledSession.class).getResultList();
	}
	
}
