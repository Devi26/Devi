package com.cg.dao;
import java.util.List;
import com.cg.dto.ScheduledSession;

public interface SessionDao {
	List<ScheduledSession> getAllSessions();
}
