package com.cg.service;
import java.util.List;
import com.cg.dto.ScheduledSession;

public interface SessionService {
	public List<ScheduledSession> getAllSessions();
}
