package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.SessionDao;
import com.cg.dto.ScheduledSession;

@Service
public class SessionServiceImpl implements SessionService {

	@Autowired
	SessionDao sessionDao = null;
	//getter, setters
	
	public SessionDao getSessionDao() {
		return sessionDao;
	}
	public void setSessionDao(SessionDao sessionDao) {
		this.sessionDao = sessionDao;
	}

	@Override
	public List<ScheduledSession> getAllSessions() {
		
		return sessionDao.getAllSessions();
	}
}
