package com.cg.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.dto.ScheduledSession;
import com.cg.service.SessionService;

@Controller
public class SessionController {
	
	@Autowired
	SessionService sessionService = null;
	//getter, setters

	public SessionService getSessionService() {
		return sessionService;
	}

	public void setSessionService(SessionService sessionService) {
		this.sessionService = sessionService;
	}
	
	@RequestMapping(value="/SceduledSession", method=RequestMethod.GET)
	public String dispSessionManagementPage(Model model){
		
		ArrayList<ScheduledSession> sessions = (ArrayList<ScheduledSession>) sessionService.getAllSessions();
		model.addAttribute("sessions",sessions);
		return "SceduleSessions";	
	}
	
	@RequestMapping(value="EnrollMe", method= RequestMethod.GET)
    public String getSuccessPage(@RequestParam(value="s_name")String sName, Model model) {
        model.addAttribute("session_name", sName);
        return "EnrollMe";  
    }
}
