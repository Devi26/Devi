package com.cg.bean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEmpDemo {

	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("cgBeans.xml");
		
		Employee employee1 = (Employee) ctx.getBean("deviObject");
		System.out.println("-------Employee Info-------");
		System.out.println("ID : " + employee1.getEmpId() + " Emp Name : " + employee1.getEmpName()
		+ " Salary : " + employee1.getEmpSal() + " Emp Address : " + 
				employee1.getEmpAdd().getState() + ","
		+ employee1.getEmpAdd().getCity() + "," + employee1.getEmpAdd().getZipcode());
		//By using ArrayList
		Emp emp1 = (Emp) ctx.getBean("suryaObject");
		System.out.println("-------Employee Info-------");
		System.out.println("ID : " + emp1.getEmpId() + " Emp Name : " + emp1.getEmpName()
		+ " Salary : " + emp1.getEmpSal() + " Emp Address : " + emp1.getEmpAdd());
	}
}
