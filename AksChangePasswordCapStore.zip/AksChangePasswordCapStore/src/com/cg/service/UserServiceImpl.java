package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.UserDetails;
import com.cg.dao.UserDAO;
import com.cg.dao.UserDAOImpl;

@Service
public class UserServiceImpl implements UserService{


	@Autowired
	UserDAO userDAO =new UserDAOImpl();

	public UserDAO getUserDAO() {
		return userDAO;
	}
	public void setUserDAO(UserDAO userDAO) {
		this.userDAO = userDAO;
	}
	@Override
	public UserDetails findUser(String useId) {
		return userDAO.findUser(useId);
	}
	@Override
	public UserDetails updatePassword(UserDetails user) {
		return userDAO.updatePassword(user);
	}


}

