package com.cg.service;

import com.cg.bean.UserDetails;

public interface UserService {
	public UserDetails updatePassword(UserDetails user);

	public UserDetails findUser(String useId);
}
