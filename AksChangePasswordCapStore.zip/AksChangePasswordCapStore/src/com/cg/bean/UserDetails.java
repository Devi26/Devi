package com.cg.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="USER_DETAILS")
public class UserDetails {

	@Id
	@Column(name="USER_ID")
	private int useId;
	private String userName;
	@Transient
	private String oldPassword;
	@Transient
	private String newPassword;
	@Transient
	private String confirmPassword;
	public UserDetails() {
		super();
	}
	public UserDetails(String userName, String oldPassword, String newPassword, String confirmPassword) {
		super();
		this.userName = userName;
		this.oldPassword = oldPassword;
		this.newPassword = newPassword;
		this.confirmPassword = confirmPassword;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getOldPassword() {
		return oldPassword;
	}
	public void setOldPassword(String oldPassword) {
		this.oldPassword = oldPassword;
	}
	public String getNewPassword() {
		return newPassword;
	}
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}
	public String getConfirmPassword() {
		return confirmPassword;
	}
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	public int getUseId() {
		return useId;
	}
	public void setUseId(int useId) {
		this.useId = useId;
	}
	public UserDetails(int useId, String userName, String oldPassword, String newPassword, String confirmPassword) {
		super();
		this.useId = useId;
		this.userName = userName;
		this.oldPassword = oldPassword;
		this.newPassword = newPassword;
		this.confirmPassword = confirmPassword;
	}
	@Override
	public String toString() {
		return "UserDetails [useId=" + useId + ", userName=" + userName + ", oldPassword=" + oldPassword
				+ ", newPassword=" + newPassword + ", confirmPassword=" + confirmPassword + "]";
	}
	
	
}
