package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.bean.UserDetails;
import com.cg.service.UserService;



@org.springframework.stereotype.Controller
public class Controller {

	@Autowired
	UserService service = null;
	//Getters & Setters
	public UserService getService() {
		return service;
	}
	public void setService(UserService service) {
		this.service = service;
	}
	@RequestMapping(value="/ShowUpdatePage", method=RequestMethod.GET)
	public String UpdatePassword(Model model) {
		UserDetails details = new UserDetails();
		model.addAttribute("password",details);
		return "ModifyPage";	
	}
	@RequestMapping(value = "/UpdatePassword.obj", method = RequestMethod.POST)
	public String updateUserDetails(@ModelAttribute(value="user") UserDetails user, Model model) {
		model.addAttribute("user", service.findUser(user.getUserName()));
		return "UpdatedPassword";
	}
}

/*@RequestMapping(value = "/UpdateUserDetails", method = RequestMethod.GET)
public String updateDetails(Model model) {
    User user = new User();
    model.addAttribute("user", user);
    return "UpdateUserPage";
}
@RequestMapping(value = "/UpdateUser.obj", method = RequestMethod.POST)
public String updateUserDetails(@ModelAttribute(value="user") User user, Model model) {
    model.addAttribute("user", userSevice.findUser(user.getUser_id()));
    return "UpdatedUserPage";
}
@RequestMapping(value = "/UpdatedUser.obj", method = RequestMethod.POST)
public String updatedUserDetails(@ModelAttribute(value="user") User user, Model model) {
    user = userSevice.updateUser(user);
    model.addAttribute("message", "User updated");
    return "UpdatedUserPage";
}
 */