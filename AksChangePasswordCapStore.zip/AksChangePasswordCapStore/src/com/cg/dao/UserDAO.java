package com.cg.dao;

import com.cg.bean.UserDetails;

public interface UserDAO {
	public UserDetails updatePassword(UserDetails user);
	public UserDetails findUser(String useId);
}
