package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.bean.UserDetails;
@Repository
@Transactional
public class UserDAOImpl implements UserDAO {

	@PersistenceContext
	EntityManager entityManager =null;

	public EntityManager getEntityManager() {
		return entityManager;
	}
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	
	@Override
	public UserDetails findUser(String useId) {
		
		return entityManager.find(UserDetails.class, useId);
	}
	
	@Override
	public UserDetails updatePassword(UserDetails user) {
		entityManager.merge(user);
		return user;
	}
}
