package com.cg.bean;

import java.util.Set;
import java.util.TreeSet;

class CreateObject
{
	public static void main(String []args)
	{
		Set set = new TreeSet();
		set.add("Priya");
		set.add("Ritu");
		set.add(100);
		System.out.println(set);
	}
}