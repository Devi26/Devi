package com.cg.bean;

public class Foo 
{  
    public static void main(String[] args) 
    {
        try 
        { 
        	System.out.println( "Finally" ); 
        } 
        catch (Exception e) {
        	System.out.println( "Finally" ); 
		}
        finally 
        {
            System.out.println( "Finally" ); 
        } 
    } 
}