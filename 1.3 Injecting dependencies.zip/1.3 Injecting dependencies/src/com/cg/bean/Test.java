package com.cg.bean;

public class Test{
    public static void main(String[] args){
            int[] a = new int[1];
            System.out.print(a.length);
    }
}