package com.cg.bean;

public class Demos1 {
	public static void main(String[] args) {
		int arr[]={1,2,3,4,5};
		for(int ele:arr){
			System.out.print(arr);
		}
	}
}