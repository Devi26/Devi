class DemoCmp implements Comparable
 //line 1
{
int number;
public DemoCmp(int num)
{
number=num;
}
//line 2
@Override
public int compareTo(Object arg0) {
	// TODO Auto-generated method stub
	return 0;
}
}
public class CreateDemo 
{
public static void main(String []args){
TreeSet<DemoCmp>set = new TreeSet<DemoCmp>();
set.add(new Demo(8));
set.add(new Demo(2));
set.add(new Demo(3));
}}