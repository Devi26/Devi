package com.cg.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEmployee {

	public static void main(String[] args) {
	ApplicationContext ctx = new ClassPathXmlApplicationContext("cg.xml");
	
	SBU sbu = (SBU) ctx.getBean("SBUObj");
	System.out.println("SBU Details");
	System.out.println("---------------------------");
	System.out.println("sbuId = " + sbu.getSbuId() + " , sbuName = " + sbu.getSbuName() 
	+ " , sbuHead = " + sbu.getSbuHead());
	
	System.out.println("Employee Details");
	System.out.println("---------------------------");
	System.out.println(sbu.getEmpList());
	}
}
