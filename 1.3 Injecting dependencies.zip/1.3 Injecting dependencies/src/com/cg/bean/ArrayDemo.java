package com.cg.bean;

class ArrayDemo
{
public static void main(String []args){
String str = "Hello World";
int []arr = {1,2,3,4,5};
display(arr,str);
}
public static void display(int �arr,String str)
{
for(int num:arr){System.out.println(num);}
System.out.println(str);
}
}