package com.cg.capstore.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.capstore.bean.Address;
import com.cg.capstore.bean.User;
import com.cg.capstore.service.UserSevice;
@Controller
public class UserController {

	@Autowired
	UserSevice userSevice = null;
	//Getters and Setters
	public UserSevice getUserSevice() {
		return userSevice;
	}
	public void setUserSevice(UserSevice userSevice) {
		this.userSevice = userSevice;
	}
	/*****************************ShowCustomerProfile***************************/
	@RequestMapping(value = "/CustomerProfile", method = RequestMethod.GET)
	public String displayCustomerProfilePage(Model model) {
		User user = new User();
		model.addAttribute("user", user);
		return "CustomerProfilePage";
	}
	/*****************************UpdateUserDetails***************************/	
	@RequestMapping(value = "/UpdateUserDetails", method = RequestMethod.GET)
	public String updateDetails(Model model) {
		User user = new User();
		model.addAttribute("user", user);
		return "UpdateUserPage";
	}
	@RequestMapping(value = "/UpdateUser.obj", method = RequestMethod.POST)
	public String updateUserDetails(@ModelAttribute(value="user") User user, Model model) {
		model.addAttribute("user", userSevice.findUser(user.getUser_id()));
		return "UpdatedUserPage";
	}
	@RequestMapping(value = "/UpdatedUser.obj", method = RequestMethod.POST)
	public String updatedUserDetails(@ModelAttribute(value="user") User user, Model model) {
		user = userSevice.updateUser(user);
		model.addAttribute("message", "User updated");
		return "UpdatedUserPage";
	}
	/*****************************UpdateUserDetails***************************/
	@RequestMapping(value = "/UpdateAddressDetails", method = RequestMethod.GET)
	public String updateAddress(Model model) {
		Address address = new Address();
		model.addAttribute("address", address);
		return "UpdateAddressPage";
	}
	@RequestMapping(value = "/UpdateAddress.obj", method = RequestMethod.POST)
	public String updateAddressDetails(@ModelAttribute(value="address") Address address, Model model) {
		Address address1=userSevice.findAddress(address.getAddress_id());
		model.addAttribute("address",address1);
		return "UpdatedAddressPage";
	}
	@RequestMapping(value = "/UpdatedAddress.obj", method = RequestMethod.POST)
	public String updatedAddressDetails(@ModelAttribute(value="address") Address address, Model model) {
		address = userSevice.updateAddress(address);
		model.addAttribute("message", "Address Updated");
		return "UpdatedAddressPage";	
	}
}
