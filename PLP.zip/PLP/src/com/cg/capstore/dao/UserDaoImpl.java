package com.cg.capstore.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.capstore.bean.Address;
import com.cg.capstore.bean.User;

@Repository
@Transactional
public class UserDaoImpl implements UserDao {

	@PersistenceContext
	EntityManager entityManager = null;
	
	//Getters and Setters
	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	//find functionality for User
	@Override
	public User findUser(String userId) {	
		return entityManager.find(User.class, userId);
	}
	//update functionality for User
	@Override
	public User updateUser(User user) {
		User user2 = entityManager.merge(user);
		entityManager.flush();
		return user2;
	}
	//find functionality for Address
	@Override
	public Address findAddress(String address_id) {
		return entityManager.find(Address.class, address_id);
	}
	//update functionality for Address
	@Override
	public Address updateAddress(Address address) {
		Address address2 = entityManager.merge(address);
		entityManager.flush();
		return address2;
	}
}
