package com.cg.capstore.dao;
import com.cg.capstore.bean.Address;
import com.cg.capstore.bean.User;
public interface UserDao {
	//for User table
	public User findUser(String userId);
	public User updateUser(User user);
	//for Address table
	public Address findAddress(String address_id);
	public Address updateAddress(Address address);
}
