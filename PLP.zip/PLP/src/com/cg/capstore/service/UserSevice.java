package com.cg.capstore.service;
import com.cg.capstore.bean.Address;
import com.cg.capstore.bean.User;
public interface UserSevice {
	//for User table
	public User findUser(String userId);
	public User updateUser(User user);
	//for Address table
	public Address findAddress(String address_id);
	public Address updateAddress(Address address);
}
