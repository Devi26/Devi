package com.cg.capstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.bean.Address;
import com.cg.capstore.bean.User;
import com.cg.capstore.dao.UserDao;

@Service
public class UserServiceImpl implements UserSevice  {

	@Autowired
	UserDao userDao = null;
	//Getters and Setters
	public UserDao getUserDao() {
		return userDao;
	}
	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}
	//find functionality
	@Override
	public User findUser(String userId) {
		return userDao.findUser(userId);
	}
	//Update functionality
	@Override
	public User updateUser(User user) {
		return userDao.updateUser(user);
	}
	//find functionality for Address
	@Override
	public Address findAddress(String address_id) {
		return userDao.findAddress(address_id);
	}
	//update functionality for Address
	@Override
	public Address updateAddress(Address address) {
		return userDao.updateAddress(address);
	}
}
