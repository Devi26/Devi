package com.cg.bean;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class BirthDayGreeting implements IGreet, BeanNameAware, BeanFactoryAware,
		DisposableBean,InitializingBean {
	
	
	String firstName;
	public BirthDayGreeting() {
		System.out.println("In BirthdayGreeting " + "Constructor");
	}	
	
	public BirthDayGreeting(String firstName) {
		super();
		this.firstName = firstName;
	}

	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
		System.out.println("------setFirstName() called...." );
	}
	@Override
	public String greetMe() {
		
		return "Happy Birthday : " + firstName;
	}

	@Override
	public void setBeanName(String beName) {

	System.out.println("In setBeanName() called...." + beName);	
	}

	@Override
	public void setBeanFactory(BeanFactory bf) throws BeansException {
		System.out.println("-------- setBeanFactory() called..... " + bf.toString());
		
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("This is called after firstName.....");
		
	}

	@Override
	public void destroy() throws Exception {
		System.out.println("destroy is called.....");
		
	}
	
	public void cgInit() {
		System.out.println("This is custom cgInit()");
	}
	
	public void cgdestroy() {
		System.out.println("This is custom cgdestroy()");
	}
}
