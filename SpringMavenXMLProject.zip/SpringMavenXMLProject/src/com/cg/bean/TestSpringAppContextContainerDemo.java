package com.cg.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestSpringAppContextContainerDemo {

	public static void main(String[] args) {
	ApplicationContext ctx = new ClassPathXmlApplicationContext("cg.xml");
	System.out.println("----------Spring Container was initialized----------");
	
	System.out.println("-----------------Birthday wish-------------");
	IGreet g1 = (IGreet) ctx.getBean("obj1");
	System.out.println(g1.greetMe());
	System.out.println(g1.hashCode());
	
	System.out.println("-----------------Birthday wish-------------");
	IGreet g3 = (IGreet) ctx.getBean("obj1");
	System.out.println(g3.greetMe());
	System.out.println(g3.hashCode());
	
	System.out.println("-----------------Birthday wish-------------");
	IGreet g6 = (IGreet) ctx.getBean("obj3");
	System.out.println(g6.greetMe());
	System.out.println(g6.hashCode());
	
	System.out.println("--------------New Year Wish---------------");	
	IGreet g2 = (IGreet) ctx.getBean("obj2");
	System.out.println(g2.greetMe());
	System.out.println(g2.hashCode());
	
	System.out.println("--------------New Year Wish---------------");
	IGreet g4 = (IGreet) ctx.getBean("obj2");
	System.out.println(g4.greetMe());
	System.out.println(g4.hashCode());
	
	System.out.println("--------------New Year Wish---------------");
	IGreet g5 = (IGreet) ctx.getBean("obj4");
	System.out.println(g5.greetMe());
	System.out.println(g5.hashCode());

	}

}
