package com.cg.staticdb;

import java.util.ArrayList;

import com.cg.bean.Country;

public class CountryDb {
	private static ArrayList<Country> countryList = new ArrayList<Country>();
	
	static {
		countryList.add(new Country("1001", "India", "3234567"));
		countryList.add(new Country("1002", "Pakistan", "67890"));
		countryList.add(new Country("1003", "SriLanka", "57635474"));
		countryList.add(new Country("1004", "China", "35433543"));
		countryList.add(new Country("1005", "USA", "2132436"));	
	}

	public static ArrayList<Country> getCountryList() {
		return countryList;
	}

	public static void setCountryList(ArrayList<Country> countryList) {
		CountryDb.countryList = countryList;
	}
}
