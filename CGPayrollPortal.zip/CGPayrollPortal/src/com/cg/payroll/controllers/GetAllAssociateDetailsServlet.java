package com.cg.payroll.controllers;
import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
@WebServlet("/GetAllAssociateDetails")
public class GetAllAssociateDetailsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    PayrollServices payrollServices=new PayrollServicesImpl();
    RequestDispatcher dispatcher=null;
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    List<Associate>associates=payrollServices.getAllAssociateDetails();
    dispatcher=request.getRequestDispatcher("allAssociateDetailsPage.jsp");
    request.setAttribute("associates", associates);
    dispatcher.forward(request, response);
    }

}