package com.cg.payroll.services;

import java.util.List;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAOImpl;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;
import com.cg.payroll.exception.InvalidEmailException;

public class PayrollServicesImpl implements PayrollServices{

	//private AssociateDAO associateDAO = new AssociateDAOImpl();

	private AssociateDAO associateDAO;

	public PayrollServicesImpl() {
		associateDAO = new AssociateDAOImpl();
	}

	public PayrollServicesImpl(AssociateDAO associateDAO) {
		super();
		this.associateDAO = associateDAO;
	}

	@Override
	public int acceptAssociateDetails(Associate associate ) throws InvalidEmailException {
		associate=associateDAO.save(associate);
		//Testing

		if(!associate.getEmailId().contains("@")) throw new InvalidEmailException();
		return associate.getAssociateID();
	}

	@Override
	public int calculateNetSalary(int associateID) throws AssociateDetailsNotFoundException {

		Associate associate = new Associate(associateID);
		associate=this.getAssociateDetails(associateID);
		//associateDAO.update(associate);
		associate.getSalary().setHra(associate.getSalary().getBasicSalary() * 40/100);
		associate.getSalary().setConveyanceAllowance(associate.getSalary().getBasicSalary() * 30/100);
		associate.getSalary().setOtherAllowance(associate.getSalary().getBasicSalary() * 20/100);
		associate.getSalary().setPersonalAllowance(associate.getSalary().getBasicSalary() * 20/100);
		associate.getSalary().setMonthlyGrossSalary(associate.getSalary().getHra() + associate.getSalary().getConveyanceAllowance() +
				associate.getSalary().getOtherAllowance() + associate.getSalary().getPersonalAllowance() + associate.getSalary().getEpf() + associate.getSalary().getCompanyPf());
		associate.getSalary().setAnnualGrossSalary(associate.getSalary().getMonthlyGrossSalary() * 12);
		if (associate.getSalary().getAnnualGrossSalary() <= 250000) {
			associate.getSalary().setNetSalary(associate.getSalary().getMonthlyGrossSalary() - associate.getSalary().getCompanyPf() - associate.getSalary().getEpf());
			associateDAO.update(associate);
			return associate.getSalary().getNetSalary();
		} 
		else if (associate.getSalary().getAnnualGrossSalary() > 250000 && associate.getSalary().getAnnualGrossSalary() <= 500000 ) {
			associate.getSalary().setYearlyTax(associate.getSalary().getAnnualGrossSalary() - associate.getSalary().getCompanyPf() * 12 - associate.getSalary().getEpf() * 12 - associate.getYearlyInvestmentUnder80c()-250000);
			associate.getSalary().setYearlyTax(associate.getSalary().getYearlyTax() * 10/100);
			associate.getSalary().setMonthlyTax(associate.getSalary().getYearlyTax() / 12);
			associate.getSalary().setNetSalary(associate.getSalary().getMonthlyGrossSalary() - associate.getSalary().getCompanyPf() - associate.getSalary().getEpf() - associate.getSalary().getMonthlyTax());
			associateDAO.update(associate);
			return associate.getSalary().getNetSalary();
		} 
		else if (associate.getSalary().getAnnualGrossSalary() > 500000 && associate.getSalary().getAnnualGrossSalary() <= 1000000 ) {
			associate.getSalary().setYearlyTax(associate.getSalary().getAnnualGrossSalary() - associate.getSalary().getCompanyPf() * 12 - associate.getSalary().getEpf() * 12-associate.getYearlyInvestmentUnder80c()-500000);
			associate.getSalary().setYearlyTax(associate.getSalary().getYearlyTax() * 20/100);
			associate.getSalary().setMonthlyTax(associate.getSalary().getYearlyTax() / 12);
			associate.getSalary().setNetSalary(associate.getSalary().getMonthlyGrossSalary() - associate.getSalary().getCompanyPf() - associate.getSalary().getEpf() - associate.getSalary().getMonthlyTax());
			associateDAO.update(associate);
			return associate.getSalary().getNetSalary();	
		} 
		else {
			associate.getSalary().setYearlyTax(associate.getSalary().getAnnualGrossSalary() - associate.getSalary().getCompanyPf() * 12 - associate.getSalary().getEpf() * 12 -associate.getYearlyInvestmentUnder80c()-1000000);
			associate.getSalary().setYearlyTax(associate.getSalary().getYearlyTax() * 30/100);
			associate.getSalary().setMonthlyTax(associate.getSalary().getYearlyTax() / 12);
			associate.getSalary().setNetSalary(associate.getSalary().getMonthlyGrossSalary() - associate.getSalary().getCompanyPf() - associate.getSalary().getEpf() - associate.getSalary().getMonthlyTax());
			associateDAO.update(associate);
			return associate.getSalary().getNetSalary();
		}
	}

	@Override
	public Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException {
		Associate associate = associateDAO.findOne(associateId);
		if(associate == null) throw new AssociateDetailsNotFoundException("Associate Details Not Found " + associateId);
		return associate;
	}

	@Override
	public List<Associate> getAllAssociateDetails() {
		return associateDAO.findAll();                                                                         
	}
}
