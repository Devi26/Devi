package com.cg.dao;



import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.dto.Account;
import com.cg.dto.Transaction;


@Repository("transactionDAO")
@Transactional
public class TransactionDAOImpl implements TransactionDAO{
	@PersistenceContext	
	private EntityManager entityManager=null;
	@Override
	public Transaction save(Transaction transaction) {
		entityManager.persist(transaction);		
		return transaction;
		
		
	}

	@Override
	public boolean update(Transaction transaction) {
		entityManager.merge(transaction);
		return true;
		
	}

	@Override
	public Transaction findOne(long transactionId) {
		return entityManager.find(Transaction.class,transactionId);
		
	}

	@Override
	public List<Transaction> findAll() {
	
		Query query=entityManager.createQuery("from Transaction tra");
		return query.getResultList();  
		   
	}



}
