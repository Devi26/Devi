package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.dto.Account;

@Repository("accountDAO")
@Transactional
public class AccountDAOImpl implements AccountDAO{

	@PersistenceContext	
	EntityManager entityManager=null;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	    @Override
	    public Account save(Account account) {
			entityManager.persist(account);		
			
			Account rd=entityManager.find(Account.class,account.getAccountNo());
			entityManager.flush();
			return rd;
	    }

	    @Override
	    public boolean update(Account account) {
	    	
			entityManager.merge(account);
			return true;
	       
	    }

	    @Override
	    public Account findOne(long accountNo) {
	    	return entityManager.find(Account.class,accountNo);
	    
	    }

	    @Override
	    public List<Account> findAll() {
	    	String qry="SELECT reg From Account reg";
			TypedQuery tq=entityManager.createQuery(qry,Account.class);
			ArrayList<Account>uList=(ArrayList) tq.getResultList();
			return uList;
	            
	    }

	}
