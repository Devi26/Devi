package com.cg.service;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.dao.AccountDAO;
import com.cg.dao.AccountDAOImpl;
import com.cg.dao.TransactionDAO;
import com.cg.dao.TransactionDAOImpl;
import com.cg.dto.Account;
import com.cg.dto.Transaction;


@Service("bankingServices")
public class BankingServicesImpl implements BankingServices {
	@Autowired
	AccountDAO accountDAO=null;
	@Autowired
	TransactionDAO transactionDAO=null;
	Account account;
	
	public AccountDAO getAccountDAO() {
		return accountDAO;
	}
	public void setAccountDAO(AccountDAO accountDAO) {
		this.accountDAO = accountDAO;
	}
	public TransactionDAO getTransactionDAO() {
		return transactionDAO;
	}
	public void setTransactionDAO(TransactionDAO transactionDAO) {
		this.transactionDAO = transactionDAO;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	@Override
	public Account openAccount(String accountType, float initBalance) {
		return accountDAO.save(account);
	}
	@Override
	public float depositAmount(long accountNo, float amount) {
		Account account=accountDAO.findOne(accountNo);
		 account.setAccountBalance(account.getAccountBalance()+amount);
		 accountDAO.update(account);
		Transaction transaction=new Transaction(amount, "deposit", account);
		transactionDAO.save(transaction);
		return account.getAccountBalance();
		
	}
	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) {
		Account account=accountDAO.findOne(accountNo);
		account.setAccountBalance(account.getAccountBalance()-amount);
		accountDAO.update(account);
		Transaction transaction=new Transaction(amount, "withdraw", account);
		transactionDAO.save(transaction);
		return account.getAccountBalance();
		
	}
	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber) 
	{
		
		Account  accountTo=accountDAO.findOne(accountNoTo);
		Account accountFrom=accountDAO.findOne(accountNoFrom);
		accountTo.setAccountBalance(accountTo.getAccountBalance()+transferAmount);
		accountFrom.setAccountBalance(accountFrom.getAccountBalance()-transferAmount);
		accountDAO.update(accountFrom);
		Transaction transaction=new Transaction(transferAmount, "withdraw", account);
		transactionDAO.save(transaction);
		accountDAO.update(accountTo);
		Transaction transaction1=new Transaction(transferAmount, "withdraw", account);
		transactionDAO.save(transaction1);
		return true;

	}

	@Override
	public Account getAccountDetails(long accountNo) {
		Account account=accountDAO.findOne(accountNo);

		return account;
	}
	@Override
	public List<Account> getAllAccountDetails() {
		return (List<Account>) accountDAO.findAll();
	}
	
	@Override
	public String accountStatus(long accountNo) {
		return accountDAO.findOne(accountNo).getStatus();
	}
	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo) {
		return transactionDAO.findAll();
	}
	@Override
	public Account insertUserDetails(Account userDetails) {
		return accountDAO.save(userDetails);
		
	}

}